Projeto inicial para acompanhar a aula de rotas do módulo de React Avançado do curso DevQuest

# Passo a passo para rodar o projeto

## Para instalar os pacotes `npm install`

## Para inicializar o projeto `npm start`

Caso seu projeto abra em uma porta diferente da 3000, por exemplo 3001, acesse o arquivo src/components/posts/index.js e faça a mudança na linha 04 trocando pela porta que você está usando
`const response = await fetch('http://localhost:3001/json/posts.json')`, para que o arquivo json possa ser carregado corretamente.
