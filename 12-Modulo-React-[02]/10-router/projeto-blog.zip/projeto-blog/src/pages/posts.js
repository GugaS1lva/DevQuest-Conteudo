import { PostsList } from '../components/posts'

const Posts = () => {
    return (
        <>
            <PostsList />
        </>
    )
}

export { Posts }