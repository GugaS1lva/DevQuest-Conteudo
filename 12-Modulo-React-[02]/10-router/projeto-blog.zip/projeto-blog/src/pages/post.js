import { PostDetails } from '../components/post'

const Post = () => {
    return (
        <PostDetails />
    )
}

export { Post }