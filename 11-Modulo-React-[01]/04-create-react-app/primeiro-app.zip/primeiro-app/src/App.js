/* Código padrão do 'create-react-app'.
  import logo from './logo.svg';
  import './App.css';

  function App() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p>
            Olá, Quester! Seja muito bem vindo ao React ⚛️
          </p>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
        </header>
      </div>
    );
  }

  export default App;
*/

import './App.css';
import Botão from './components/button/botão.js'
import Card from './components/card/card.js';
import Cards from './components/cards/cards'


function App() {
  return (
    <>
      <h1>Olá!</h1>
      <div>
        <Botão label='Texto Call-Back' />
        <Botão />
        <Botão />

        <Card />
        <Card paragraph='Texto que será inserido'/>

        <br />

        <div>
          <Cards />
        </div>
      </div>
    </>
  );
}

export default App;
