import Card from "../card/card.js"
import '../cards/cards.css'

const CardsTitle = ['Inserindo texto pelo APP.JS - 01', 'Inserindo texto pelo APP.JS - 02', 'Inserindo texto pelo APP.JS - 03']

const showCardColor = (color) =>{
    console.log(color)
}

const Cards = () => {
    return (
        <div>
            <div className='cards'>
                <h2>Meus Cards</h2>
                <div>
                    {CardsTitle.map((CardsTitle, index) => (
                        <Card key={index} showCardColor={showCardColor}>
                            <h4>{CardsTitle}</h4>
                        </Card>
                    ))}

                    <Card color={'#0E4429'} showCardColor={showCardColor}>
                        <h4>Card Verde</h4>
                    </Card>
                </div>
            </div>
        </div>
    )
}

export default Cards