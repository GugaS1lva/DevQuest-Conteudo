// - NOME DA VARIÁVEL MAIÚSCOLA
// - Arrow Function
// - Retornar a tag
// - Exportar o arquivo

import React, {Component} from 'react'
import './botão.css'

/* Default Props com FUNÇÕES:
    const Botão = (props) => {
        return <button className='btn'>{props.label}</button>
    }
*/

/* Default Props com CLASS: 
    class Botão extends Component{
        render(){
            return(
                <button className='btn'>{this.props.label}</button>
            )
        }
    }
*/

const sayHello = () => {
    console.log('HELLOOOOOOO')
}

const Botão = (props) => {
    return <button className='btn' onClick={sayHello}>{props.label}</button>
}

Botão.defaultProps = {
    // label: 'teste-01',
    label: 'teste CLASS'
}

export default Botão
