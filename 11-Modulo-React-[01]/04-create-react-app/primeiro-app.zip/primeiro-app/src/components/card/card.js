// - Importar o React
// - class >>> Palavra Reservada
// - className >>> Nome da classe
// - 'extends' e 'extends React.Component' >>> Palavra reservada. Informa que quer extender características de uma outra classe pra dentro desse componente, nesse caso: 'estenda características de componentes que está dentro de React para dentro da classe de nome Cards'.
// - render(){} >>> Função que vai ser renderizada na tela
// - render(){ return() } >>> Retorna o JSX do componente.
// - export default Card >>> Prepara o arquivo para a importação em qualquer lugar do código.

/* COMPONENTE USANDO CLASSE
    import React from 'react'
    import './card.css'
    class Card extends React.Component {
        render(){
            console.log(this)
            console.log(this.props)
            console.log(this.props.paragraph)
            return(
                <div className="card">
                    <h3>Título</h3>
                    <p>{this.props.paragraph} - Lorem ipsum, dolor.</p>
                </div>
            )
        }
    }

    export default Card
*/

/* COMPONENTE USANDO FUNCTION - Arrow Function 
    import React from 'react'
    import './card.css'
    const Card = ({paragraph}) => {
        return(
            <div className="card">
                <h3>Título</h3>
                <p>{paragraph} - Lorem ipsum, dolor.</p>
            </div>        
        )
    }

    export default Card
*/

/* COMPONENTE COM CONTEÚDO DIRETO DO APP.JS */
import React from 'react'
import Cards from '../cards/cards'
import './card.css'
const Card = ({children, color, showCardColor}) => {
    return(
        <div className="card" style={{backgroundColor: color}} onClick={() => {showCardColor(color)}}>
            {children}
        </div>
    )
}

Card.defaultProps = {
    color: 'orange'
}

export default Card